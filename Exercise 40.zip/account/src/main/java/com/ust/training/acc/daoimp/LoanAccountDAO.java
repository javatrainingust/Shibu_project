/***
 * interface: LoanAccountDAO
 * 
 * Description:this interface used to implement  dao for LoanAccount
 *
 * Date:06.10.2020
 * 
*/package com.ust.training.acc.daoimp;

import java.util.List;

import com.ust.training.acc.model.FDAccount;
import com.ust.training.acc.model.LoanAccount;
/***
This interface used to implement  dao for LoanAccount 
*/
public interface LoanAccountDAO {
	/*method declaration for LoanAccountDAO interface*/
public List<LoanAccount> getAllAccounts();
	
	public LoanAccount getAccountByAccountNumber(int accountNum);
	
	public void deleteAccount(int accountNum);
	
	public boolean addAccount(LoanAccount fda);
	
	public void updateAccount(LoanAccount fda);

}
