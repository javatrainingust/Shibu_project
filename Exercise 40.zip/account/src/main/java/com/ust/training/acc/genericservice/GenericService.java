/***
 * Classname:GenericService
 * 
 * Description:to call generic service call
 *
 * Date:30.09.2020
 * 
***/		
package com.ust.training.acc.genericservice;

import com.ust.training.acc.model.Account;
import com.ust.training.acc.model.CurrentAccount;
import com.ust.training.acc.model.FDAccount;
import com.ust.training.acc.model.SBAccount;

public class GenericService extends Account{
	//main method starting Here
public static void main(String[] args) {
	SBAccount aba=new SBAccount(5000,2);
}


}
