package com.ust.training.acc.services;

import com.ust.training.acc.model.LoanAccount;
import com.ust.training.acc.model.SBAccount;

public class SBAccountAddDemo {

	public static void main(String[] args) {
		SBAccountService service=new SBAccountService();
		service.addSBAccount(new SBAccount(1510, "Sundhara", 50000));
		service.addSBAccount(new SBAccount(1511, "Aruthra", 90000));
		service.addSBAccount(new SBAccount(1512, "Viji", 99000));
		service.addSBAccount(new SBAccount(1513, "Athvi", 66000));
		
		
		System.out.println("Printing all accounts");	
		service.getAllAccounts();
		System.out.println("---------------------------------------------");	
		service.updateSBAccount(new SBAccount(1510, "Sundharalingam", 50000));
		System.out.println("Printing all updated accounts");	
		service.getAllAccounts();
		
		}
}
