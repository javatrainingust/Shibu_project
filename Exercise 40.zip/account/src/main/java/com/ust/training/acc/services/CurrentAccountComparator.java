/***
 * class: CurrentAccountComparator
 * 
 * Description:this class used to sort CurrentAccount by comparator 
 *
 * Date:07.10.2020
 * 
*/

package com.ust.training.acc.services;

import java.util.Comparator;

import com.ust.training.acc.model.CurrentAccount;
/***
 * CurrentAccountComparator class used to sort CurrentAccount by comparator 
 * 
*/

public class CurrentAccountComparator implements Comparator<CurrentAccount> {
/*
 * 
 * compare method
 */

	public int compare(CurrentAccount one, CurrentAccount two) {
		// TODO Auto-generated method stub
		return (int)(one.getBalance()-two.getBalance());
		}

}
