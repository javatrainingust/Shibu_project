/***
 * class: CurrentAccountAddDemo
 * 
 * Description:this class used to add and update CurrentAccount 
 *
 * Date:08.10.2020
 * 
*/
package com.ust.training.acc.services;

import com.ust.training.acc.model.CurrentAccount;

/***
 * CurrentAccountAddDemo class used to add and update CurrentAccount 
*/
public class CurrentAccountAddDemo {
/**
 * main method
 * */
	public static void main(String[] args) {
	CurrentAccountService service=new CurrentAccountService();
	
	service.addCurrentAccount(new CurrentAccount(1510, "Sundhara", 200000, 786765));
	service.addCurrentAccount(new CurrentAccount(1511, "Viji", 80000, 87876));
	service.addCurrentAccount(new CurrentAccount(1512, "Aruthra", 980000, 186765));
	service.addCurrentAccount(new CurrentAccount(1513, "Athvi", 540000, 56765));
	
	System.out.println("Printing all accounts");	
	service.getAllAccounts();
	System.out.println("---------------------------------------------");	
	service.updateCurrentAccount(new CurrentAccount(1510, "Sundharalingam N", 800000, 786765));
	System.out.println("Printing all updated accounts");	
	service.getAllAccounts();
	
	}

}
