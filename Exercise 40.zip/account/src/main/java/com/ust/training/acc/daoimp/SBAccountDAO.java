/***
 * interface: SBAccountDAO
 * 
 * Description:this interface used to implement  dao for SBAccount
 *
 * Date:06.10.2020
 * 
*/
package com.ust.training.acc.daoimp;

import java.util.List;

import com.ust.training.acc.model.FDAccount;
import com.ust.training.acc.model.SBAccount;
/***This interface used to implement  dao for SBAccount*/
public interface SBAccountDAO {
	/*method declaration for SBAccountDAO interface*/
	public List<SBAccount> getAllAccounts();
	
	public SBAccount getAccountByAccountNumber(int accountNum);
	
	public void deleteAccount(int accountNum);
	
	public boolean addAccount(SBAccount fda);
	
	public void updateAccount(SBAccount fda);
}
