/***
 * class: CurrentAccountRetraiveDemo
 * 
 * Description:this class used to print all and print specific accounts for CurrentAccount
 *
 * Date:06.10.2020
 * 
*/
package com.ust.training.acc.services;

/***
 * CurrentAccountRetraiveDemo class used to print all and print specific
 * accounts for CurrentAccount
 * 
 */
public class CurrentAccountRetraiveDemo {
	/**
	 * main method
	 * 
	 */
	public static void main(String[] args) {

		CurrentAccountService service = new CurrentAccountService();

		System.out.println("Printing all employees");

		service.getAllAccounts();

		System.out.println("--------------------------------");

		System.out.println("Printing a specific employee");

		service.getFDAccountByAccountNumber(1510);
	}

}
