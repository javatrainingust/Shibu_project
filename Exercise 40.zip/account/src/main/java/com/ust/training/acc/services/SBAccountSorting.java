package com.ust.training.acc.services;

public class SBAccountSorting {
	/**
	 * 
	 * Main method
	 */
	public static void main(String[] args) {
		SBAccountService service =  new SBAccountService();
		System.out.println("printing all accounts");
		
		service.getAllAccounts();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print Accounts after sorting by name");
		service.getAllAccountsSortedByNames();
		System.out.println("----------------------");
		System.out.println("Print accounts  after sorting based on balance");
		service.getAllFDAccountsSortedByFDAmount();
	}
}
