/***
 * class: SBAccountService
 * 
 * Description:this class used to implement SBAccountServicet
 *
 * Date:06.10.2020
 * 
*/
package com.ust.training.acc.services;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.training.acc.daoimp.FDADAO;
import com.ust.training.acc.daoimp.FDADAOImp;
import com.ust.training.acc.daoimp.SBAccountDAO;
import com.ust.training.acc.daoimp.SBAccountImp;
import com.ust.training.acc.model.FDAccount;
import com.ust.training.acc.model.LoanAccount;
import com.ust.training.acc.model.SBAccount;

/***
 * SBAccountService class used to implement SBAccountServicet
 * 
 */
@Service
public class SBAccountService {
	/* constructor */
	@Autowired
	SBAccountDAO daoImpl;

	public SBAccountService() {
		// TODO Auto-generated constructor stub

		daoImpl = new SBAccountImp();

	}

	/**
	 * Display all the accounts*
	 **/

	public List<SBAccount> getAllAccounts() {
		List SBAccountList = daoImpl.getAllAccounts();
		Iterator<SBAccount> iterator = SBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account Id: " + sb.getAccountNumber());
			System.out.println("Account Holder Name: " + sb.getAccountHoderName());
			System.out.println("Balance: " + sb.getBalance());
			System.out.println("************************************************");

		}

		return SBAccountList;
	}

	/**
	 * Display accounts by accountNum*
	 **/

	public SBAccount getSBAccountByAccountNumber(int getAccountNumber) {
		SBAccount sb = daoImpl.getAccountByAccountNumber(getAccountNumber);
		System.out.println("Account Number: " + sb.getAccountNumber());
		System.out.println("Account Holder Name: " + sb.getAccountHoderName());
		System.out.println("Balance: " + sb.getBalance());
		return sb;

	}

	/***
	 * Delete the account
	 **/
	public void deleteSBAccount(int accountNumber) {

		daoImpl.deleteAccount(accountNumber);
		;

	}

	/***
	 * sort all accounts by account holder names
	 ***/
	public List<SBAccount> getAllAccountsSortedByNames() {

		List<SBAccount> sbAccountList = daoImpl.getAllAccounts();

		// Collections.sort(sbAccountList);
		Stream<SBAccount> sbAccountStream = sbAccountList.stream();

		Stream<SBAccount> sortedStream = sbAccountStream.sorted();

		List sortedSBAccountList = sortedStream.collect(Collectors.toList());

		Iterator<SBAccount> iterator = sortedSBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account Number: " + sb.getAccountNumber());
			System.out.println("Account Holder Name: " + sb.getAccountHoderName());
			System.out.println("Balance: " + sb.getBalance());

			System.out.println("*********************************************");
		}

		return sbAccountList;
	}

	/***
	 * sort all accounts by FD Amount
	 ***/
	public List<SBAccount> getAllFDAccountsSortedByFDAmount() {

		List<SBAccount> sbAccountList = daoImpl.getAllAccounts();

		// Collections.sort(sbAccountList, new SBAccountComparator());
		Stream<SBAccount> sbAccounttStream = sbAccountList.stream();

		Stream<SBAccount> sortedStream = sbAccounttStream.sorted(new SBAccountComparator());

		List sortedSBAccountList = sortedStream.collect(Collectors.toList());

		Iterator<SBAccount> iterator = sortedSBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account Number: " + sb.getAccountNumber());
			System.out.println("Account Holder Name: " + sb.getAccountHoderName());
			System.out.println("Balance: " + sb.getBalance());
			System.out.println("*********************************************");
		}

		return sbAccountList;
	}

	/*
	 * *add account
	 */
	SBAccountImp sbaAccountImp = new SBAccountImp();

	public void addSBAccount(SBAccount sbAccount) {

		boolean isAdded = daoImpl.addAccount(sbAccount);

		if (!isAdded) {

			System.out.println("The account already exist");
		} else {
			System.out.println("The account successfully added");

		}
	}

	/**
	 * 
	 * update Account
	 */
	public void updateSBAccount(SBAccount sbaAccount) {
		daoImpl.updateAccount(sbaAccount);

	}

}
