/***
 * Class: FDAccountController
 * 
 * Description:this class used to implement  controller for FDAccount
 *
 * Date:15.10.2020
 * 
*/
package com.ust.training.acc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.training.acc.model.CurrentAccount;
import com.ust.training.acc.model.FDAccount;
import com.ust.training.acc.services.FDAccountService;
/***
 * FDAccountController class used to implement  controller for FDAccount
 * 
*/
@Controller
public class FDAccountController {
	@Autowired
	private FDAccountService service;
	
	@RequestMapping("/showFDform")

	public String showAccountForm(Model model) {

		FDAccount ca = new FDAccount();

		model.addAttribute("key", ca);
		return "addFDAccount";

	}
/**current account adding*/
	@RequestMapping("/addFixedDepositeAccount")
	public String addAccount(@ModelAttribute("FDAccount") FDAccount ca) {

		service.addfdAccount(ca);
		System.out.println("Inside account"+ca.getAccountNumber());
		return "redirect:/fdAccount";

	}
	/**
	 * update Account*/
	@RequestMapping("/updateFDAccounts")
	public String updateAccounts(@ModelAttribute("FDAccount") FDAccount ca) {
		
		
		service.updatefdAccount(ca);
		
		return "redirect:/fdAccount";
		
		
	}
	@RequestMapping("/fdAccount")
	/**
	 * Get All Accounts
	 * */
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<FDAccount> accountList = service.getAllAccounts();
		System.out.println("size"+accountList.size());
		model.addAttribute("fdAccount",accountList );
		
		
		return "fdAccount";
		
	}
	@RequestMapping("/sortFDccountByName")
	/**
	 * Get All Accounts
	 * */
	public String getAllFDccountByName(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<FDAccount> accountList = service.getAllAccountsSortedByNames();
		System.out.println("size"+accountList.size());
		model.addAttribute("fdAccount",accountList );
		
		
		return "fdAccount";
		
	}
	@RequestMapping("/sortFDccountBybalance")
	/**
	 * Get All Accounts
	 * */
	public String getAllFDccountBybalance(Model model){
		
		System.out.println("Inside controller getAllAccounts");
		List<FDAccount> accountList = service.getAllFDAccountsSortedByBasicBalance();
		System.out.println("size"+accountList.size());
		model.addAttribute("fdAccount",accountList );
		
		
		return "fdAccount";
		
	}
	/**
	 * Get specified account details
	 * */
	@RequestMapping("/viewFDAccount")
	public String getAccounts(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		FDAccount fd = service.getFDAccountByAccountNumber(Integer.parseInt(accountNumber));
		
		model.addAttribute("keyfd", fd);
		
		
		return "viewFDAccount";
		
		
	}
	/**
	 * Delete specified account details
	 * */
	@RequestMapping("/deleteFDAccount")
	public String deleteEmployee(@RequestParam("accountNumber")String accountNumber,Model model) {
		
		
		service.deleteFDAccount(Integer.parseInt(accountNumber));
		
				
		return "redirect:/fdAccount";
		
		
	}
}
