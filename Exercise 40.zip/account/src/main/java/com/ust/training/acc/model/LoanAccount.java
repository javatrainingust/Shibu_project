/***
 * Classname:LoanAccount
 * 
 * Description:This is a child class of Account Class. This class used to handle Loan Account  
 *
 * Date:30.09.2020
 * 
**/	
package com.ust.training.acc.model;
/**This class used to handle Loan Account **/	
public class LoanAccount extends Account implements Comparable<LoanAccount>{
	private float emi;
	private float loanOutStanding;
	private int tenture;
	private int accountNumber;
	private String accountHoderName;
	public LoanAccount() {}
	
	public LoanAccount(int accountNumber, String accountHoderName,float loanOutStanding,float emi,int tenture) {
		this.accountNumber=accountNumber;
		this.accountHoderName=accountHoderName;
		this.loanOutStanding=loanOutStanding;
		this.emi=emi;
		this.tenture=tenture;
	}
	
public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHoderName() {
		return accountHoderName;
	}
	public void setAccountHoderName(String accountHoderName) {
		this.accountHoderName = accountHoderName;
	}
/**To Set EMI**/	
public float getEmi() {
		return emi;
}
/**To Get EMI**/	
public void setEmi(float emi) {
		this.emi = emi;
}

/**To Get Loan OutStanding of EMI**/	
public float getLoanOutStanding() {
	//System.out.println("LoanOutStanding:"+loanOutStanding);
	return loanOutStanding;	
}
/**To Set Loan OutStanding of EMI**/	
public void setLoanOutStanding(float loanOutStanding) {
	loanOutStanding = this.loanOutStanding;
}
/**To Get Loan tenture of EMI**/	
public int getTenture() {
	//System.out.println("Tenture:"+tenture);
	return tenture;
}
/**To Set Loan tenture of EMI**/	
public void setTenture(int tenture) {
	tenture = tenture;
}
/*
 * 
 * override compareto method
 */

public int compareTo(LoanAccount o) {
	// TODO Auto-generated method stub
	return this.accountHoderName.compareTo(o.getAccountHoderName());
}


}
