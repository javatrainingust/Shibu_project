/**
 * Class-AccountMapper
 * Description-This class is used to map Loan account
 * date-23-20-2020
 */
package com.ust.training.acc.daoimp;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.ust.training.acc.model.LoanAccount;


/***
 * 
 * This class is used to map Loan account
 *
 */

public class LoanAccountMapper implements RowMapper<LoanAccount>{
	/**
	 * Method map-row is written below
	 * 
	 */
  public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		
	    LoanAccount la =  new LoanAccount();
		
		la.setAccountHoderName(rs.getString("accountHoderName"));
		la.setAccountNumber(rs.getInt("accountNumber"));
		la.setEmi(rs.getInt("emi"));
		la.setLoanOutStanding(rs.getFloat("loanOutStanding"));
		la.setTenture(rs.getInt("tenture"));
		
		return la;
	}

}