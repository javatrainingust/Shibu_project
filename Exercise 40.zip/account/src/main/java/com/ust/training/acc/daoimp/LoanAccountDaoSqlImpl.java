/**
 * Class-LoanAccount
 * Description-This class is for get,update,delete loanaccount using database
 * Date-23-20-2020
 */
package com.ust.training.acc.daoimp;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ust.training.acc.model.LoanAccount;

/**
 * 
 * This class is for get,update,delete loanaccount using database
 *
 */
@Repository
public class LoanAccountDaoSqlImpl implements LoanAccountDAO {
	
	private DataSource dataSource;
    private JdbcTemplate jdbcTemplateObject;
		/***
		 * 
		 * Setting data-source
		 */
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
		
		/**
		 * To get all Loan Accounts
		 */

	public List<LoanAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		String SQL = "select * from loanaccount";
	    List <LoanAccount> la= jdbcTemplateObject.query(SQL, new LoanAccountMapper());
		return la;
	}
       /**
        * 
        * To get account be account number
        */
	public LoanAccount getAccountByAccountNumber(int accountNum) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM loanaccount WHERE accountNumber = ?";
		 
		LoanAccount la = (LoanAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNum }, new LoanAccountMapper());
      
       return 	la;
	}
         /***
          *To delete account using account number 
          * 
          */
	public void deleteAccount(int accountNum) {
		// TODO Auto-generated method stub
		String query="delete from loanaccount where accountNumber='"+accountNum+"' ";  
		jdbcTemplateObject.update(query); 
	}
	
	/**
	 * To add loan account
	 * 
	 */
     public boolean addAccount(LoanAccount loanaccount) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO loanaccount " +
	            "(accountNumber,accountHoderName,loanOutStanding,emi,tenture) VALUES (?, ?, ? ,? ,?)";
	  
	        
	  
		jdbcTemplateObject.update(sql, new Object[] { loanaccount.getAccountNumber(),
				loanaccount.getAccountHoderName(), loanaccount.getLoanOutStanding(),loanaccount.getEmi(),loanaccount.getTenture()
	        });
		return true;
	}
       /**
        * to update loan account
        */
	public void updateAccount(LoanAccount loanaccount) {
		// TODO Auto-generated method stub
		String query="update loanaccount set  balance='"+loanaccount.getLoanOutStanding()+"',accountHoderName='"+loanaccount.getAccountHoderName()+"' where accountNumber='"+loanaccount.getAccountNumber()+"' ";  
	    jdbcTemplateObject.update(query); 
	}

}
