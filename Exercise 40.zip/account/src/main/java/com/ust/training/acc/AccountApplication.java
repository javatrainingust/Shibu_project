/**
 * class-AccountApplication
 * Description-This is the main class to run the spring boot application
 * Date-27-10-2020
 */
package com.ust.training.acc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/***
 * 
 * This is the main class to run the spring boot application
 *
 */
@SpringBootApplication
public class AccountApplication {
    /**
     * 
     * Main Method
     */
	public static void main(String[] args) {
		SpringApplication.run(AccountApplication.class, args);
	}

}
