/***
 * class: LoanAccountComparator
 * 
 * Description:this class used to sort LoanAccount by comparator 
 *
 * Date:07.10.2020
 * 
*/
package com.ust.training.acc.services;

import java.util.Comparator;

import com.ust.training.acc.model.LoanAccount;
/***
  LoanAccountComparator class used to sort LoanAccount by comparator 
 * 
*/
public class LoanAccountComparator implements Comparator<LoanAccount> {

	public int compare(LoanAccount one, LoanAccount two) {
		// TODO Auto-generated method stub
		return (int)(one.getEmi()-two.getEmi());
		}}

