/***
 * class: FDAccountDeleteDemo
 * 
 * Description:this class used to delete and print for FDAccount
 *
 * Date:06.10.2020
 * 
*/
package com.ust.training.acc.services;

/***
 * FDAccountDeleteDemo class used to delete and print for FDAccount
 * 
 */
public class FDAccountDeleteDemo {
	/**
	 * 
	 *  main method 
	 *  
	 *  **/
	public static void main(String[] args) {

		FDAccountService service = new FDAccountService();

		System.out.println("Printing all employees");

		service.getAllAccounts();

		System.out.println("----------------------------------");

		service.deleteFDAccount(1510);

		System.out.println("After deletion");

		service.getAllAccounts();

	}

}
