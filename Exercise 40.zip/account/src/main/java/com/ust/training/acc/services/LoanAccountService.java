/***
 * class: LoanAccountService
 * 
 * Description:this class used to implement LoanAccountService
 *
 * Date:06.10.2020
 * 
*/
package com.ust.training.acc.services;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.training.acc.daoimp.FDADAO;
import com.ust.training.acc.daoimp.LoanAccountDAO;
import com.ust.training.acc.daoimp.LoanAccountDAOImp;
import com.ust.training.acc.daoimp.SBAccountDAO;
import com.ust.training.acc.daoimp.SBAccountImp;
import com.ust.training.acc.model.FDAccount;
import com.ust.training.acc.model.LoanAccount;
import com.ust.training.acc.model.SBAccount;

/***
 * LoanAccountService class used to implement LoanAccountService
 * 
 */
@Service
public class LoanAccountService {
	/* contructor */
	@Autowired
	LoanAccountDAO daoImpl;

	public LoanAccountService() {
		// TODO Auto-generated constructor stub

		daoImpl = new LoanAccountDAOImp();

	}

	/**
	 * Display all the accounts*
	 **/

	public List<LoanAccount> getAllAccounts() {
		List LoanAccountList = daoImpl.getAllAccounts();

		Iterator<LoanAccount> iterator = LoanAccountList.iterator();

		while (iterator.hasNext()) {

			LoanAccount la = iterator.next();

			System.out.println("Loan Id: " + la.getAccountNumber());
			System.out.println("Loan Account Holder Name: " + la.getAccountHoderName());
			System.out.println("Loan Amount: " + la.getLoanOutStanding());
			System.out.println("EMI:" + la.getEmi());
			System.out.println("Tenture:" + la.getTenture());
			System.out.println("************************************************");

		}

		return LoanAccountList;
	}

	/**
	 * Display accounts by accountNum*
	 **/
	public LoanAccount getLoanAccountByAccountNumber(int getAccountNumber) {
		LoanAccount la = daoImpl.getAccountByAccountNumber(getAccountNumber);
		System.out.println("Loan Id: " + la.getAccountNumber());
		System.out.println("Loan Account Holder Name: " + la.getAccountHoderName());
		System.out.println("Loan Amount: " + la.getLoanOutStanding());
		System.out.println("EMI:" + la.getEmi());
		System.out.println("Tenture:" + la.getTenture() + " Years");
		return la;

	}

	/* Delete the account */
	public void deleteLoanAccount(int accountNumber) {

		daoImpl.deleteAccount(accountNumber);
		;

	}

	/***
	 * sort all accounts by account holder names***/
	public List<LoanAccount>	getAllAccountsSortedByNames(){
		
		
		List<LoanAccount> loanAccountList = daoImpl.getAllAccounts();
		
		//Collections.sort(loanAccountList);
Stream<LoanAccount> loanAccountStream = loanAccountList.stream();
		
		Stream<LoanAccount> sortedStream = loanAccountStream.sorted();
		
		List sortedLoanAccountList = sortedStream.collect(Collectors.toList());
			
		Iterator<LoanAccount> iterator = sortedLoanAccountList.iterator();
		
		while(iterator.hasNext()){
			
			LoanAccount la = iterator.next();
			

			System.out.println("Loan Id: " + la.getAccountNumber());
			System.out.println("Loan Account Holder Name: " + la.getAccountHoderName());
			System.out.println("Loan Amount: " + la.getLoanOutStanding());
			System.out.println("EMI:" + la.getEmi());
			System.out.println("Tenture:" + la.getTenture() + " Years");
			
			System.out.println("*********************************************");
			}			
		
		
		
		return loanAccountList;
	}
	/***
	 * sort all accounts by EMI***/
		
public List<LoanAccount>	getAllFDAccountsSortedByEMI(){
		
	List<LoanAccount> loanAccountList = daoImpl.getAllAccounts();
		
		//Collections.sort(loanAccountList,new LoanAccountComparator());
		
	Stream<LoanAccount> loanAccounttStream = loanAccountList.stream();
	
	Stream<LoanAccount> sortedStream = loanAccounttStream.sorted(new LoanAccountComparator());
	
	List sortedFDAccountList = sortedStream.collect(Collectors.toList());
	
		Iterator<LoanAccount> iterator = sortedFDAccountList.iterator();
		
		while(iterator.hasNext()){
			
		LoanAccount la = iterator.next();
			

			System.out.println("Loan Id: " + la.getAccountNumber());
			System.out.println("Loan Account Holder Name: " + la.getAccountHoderName());
			System.out.println("Loan Amount: " + la.getLoanOutStanding());
			System.out.println("EMI:" + la.getEmi());
			System.out.println("Tenture:" + la.getTenture() + " Years");
			
			System.out.println("*********************************************");
			}			
		
		
		
		return loanAccountList;
	}
LoanAccountDAOImp laDAOImp=new LoanAccountDAOImp();
/**
 * add account
 * */	public void addloanAccount(LoanAccount laAccount) {
	
	boolean isAdded = daoImpl.addAccount(laAccount);
		
	
	if(!isAdded){
		
		System.out.println("The account already exist");
	}
	else{
		System.out.println("The account successfully added");
		
	}
	
}
/**
 * update account
 * */
public void updateloanAccount(LoanAccount laAccount){
	
	daoImpl.updateAccount(laAccount);
	
}	

}

