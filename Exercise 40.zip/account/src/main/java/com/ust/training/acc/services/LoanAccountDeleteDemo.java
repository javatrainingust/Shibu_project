/***
 * class: LoanAccountService
 * 
 * Description:this class used to delete and print for LoanAccount
 *
 * Date:06.10.2020
 * 
*/
package com.ust.training.acc.services;

/***
 * LoanAccountService class used to delete and print for LoanAccount
 * 
 */
public class LoanAccountDeleteDemo {
/**
 * 
 * main method
 * @param args
 */

	public static void main(String[] args) {

		LoanAccountService service = new LoanAccountService();

		System.out.println("Printing all employees");

		service.getAllAccounts();

		System.out.println("----------------------------------");

		service.deleteLoanAccount(1510);

		System.out.println("After deletion");

		service.getAllAccounts();

	}
}
