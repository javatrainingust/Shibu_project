/***
 * class: SBAccountRetraivalDemo
 * 
 * Description:this class used to print all and print specific accounts for SBAccount
 *
 * Date:06.10.2020
 * 
*/
package com.ust.training.acc.services;
/***
 *SBAccountRetraivalDemo class used to print all and print specific accounts for SBAccount
*/
public class SBAccountRetraivalDemo {
/**
 * 
 * main method
 * 
 * **/
public static void main(String[] args) {
		
		SBAccountService service  =  new SBAccountService();
		
		System.out.println("Printing all Accounts");
		
		service.getAllAccounts();
		
		System.out.println("--------------------------------");
		
		System.out.println("Printing a specific Account");
		
		service.getSBAccountByAccountNumber(1510);
	}
}
