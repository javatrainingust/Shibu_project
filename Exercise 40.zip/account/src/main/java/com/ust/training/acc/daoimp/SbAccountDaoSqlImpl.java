/***
 * class-SbAccountDaoSqlImpl
 * Description-This class is used to get,update,delete sba-account using database
 * Date-23-10-2020
 */
package com.ust.training.acc.daoimp;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ust.training.acc.model.SBAccount;
/***
 * This class is used to get,update,delete sba-account using database
 */
@Repository
public class SbAccountDaoSqlImpl implements SBAccountDAO{
	
	private DataSource dataSource;
    private JdbcTemplate jdbcTemplateObject;
		/***
		 * 
		 * Setting data-source
		 */
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
        /****
         * Method to get all sba Accounts
         */
	public List<SBAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		String SQL = "select * from sbaccount";
	    List <SBAccount> sbAccount= jdbcTemplateObject.query(SQL, new AccountMapper());
		return sbAccount;
	}
         /****
          * Method to get sbaaccount be account number
          */
	public SBAccount getAccountByAccountNumber(int accountNum) {
		String sql = "SELECT * FROM sbaccount WHERE accountNumber = ?";
		 
		SBAccount sb = (SBAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNum }, new AccountMapper());
      
       return 	sb;
	}
         /***
          * 
          * Method to delete sb account
          * 
          */
	public void deleteAccount(int accountNum) {
		// TODO Auto-generated method stub
		String query="delete from sbaccount where accountNumber='"+accountNum+"' ";  
		jdbcTemplateObject.update(query); 
	}
            /*****
             * 
             * Method to add one sba account
             * 
             * 
             */
	public boolean addAccount(SBAccount sbaccount) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO sbaccount " +
	            "(accountNumber,accountHoderName,balance) VALUES (?, ?, ?)";
	  
	        
	  
		jdbcTemplateObject.update(sql, new Object[] { sbaccount.getAccountNumber(),
				sbaccount.getAccountHoderName(), sbaccount.getBalance()
	        });
		return true;
	}
           /***
            *    
            * 
            * Method to update sba account
            */
	public void updateAccount(SBAccount sbaccount) {
		// TODO Auto-generated method stub
		String query="update sbaccount set  balance='"+sbaccount.getBalance()+"',accountHoderName='"+sbaccount.getAccountHoderName()+"' where accountNumber='"+sbaccount.getAccountNumber()+"' ";  
	    jdbcTemplateObject.update(query); 
	}

}
