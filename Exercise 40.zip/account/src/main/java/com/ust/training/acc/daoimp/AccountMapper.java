/**
 * Class-AccountMapper
 * Description-This class is used to map sba account
 * date-23-20-2020
 */
package com.ust.training.acc.daoimp;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ust.training.acc.model.SBAccount;

/***
 * 
 * This class is used to map sba account
 *
 */

public class AccountMapper implements RowMapper<SBAccount>{
	/**
	 * Method map-row is written below
	 * 
	 */
  public SBAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		
	    SBAccount sb =  new SBAccount();
		
		sb.setAccountHoderName(rs.getString("accountHoderName"));
		sb.setAccountNumber(rs.getInt("accountNumber"));
		sb.setBalance(rs.getFloat("balance"));
		
		return sb;
	}

}
