/***
 * class: FDAccountComparator
 * 
 * Description:this class used to sort FDAccount by comparator 
 *
 * Date:07.10.2020
 * 
*/
package com.ust.training.acc.services;

import java.util.Comparator;

import com.ust.training.acc.model.FDAccount;
/***
 *FDAccountComparator class used to sort FDAccount by comparator 
 *
*/
public class FDAccountComparator implements Comparator<FDAccount> {
/**
 * main method*/

	public int compare(FDAccount one, FDAccount two) {
		// TODO Auto-generated method stub
		return (int)(one.getFixedDepositAmount()-two.getFixedDepositAmount());
		}



}
