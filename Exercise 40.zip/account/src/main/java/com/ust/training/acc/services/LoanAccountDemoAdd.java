/***
 * class: LoanAccountDemoAdd
 * 
 * Description:this class used to add and update loanAccount 
 *
 * Date:08.10.2020
 * 
*/package com.ust.training.acc.services;

import com.ust.training.acc.model.FDAccount;
import com.ust.training.acc.model.LoanAccount;

public class LoanAccountDemoAdd {

	/**
	 * main method
	 * */
		public static void main(String[] args) {
		LoanAccountService service=new LoanAccountService();
		service.addloanAccount(new LoanAccount(1510, "Sundhara", 5000, 500, 2));
		service.addloanAccount( new LoanAccount(1511, "Viji", 5679, 700, 1));
		service.addloanAccount(new LoanAccount(1512, "Aruthra", 8976, 567, 3));
		service.addloanAccount(new LoanAccount(1513, "Athvi", 6700, 590, 4));
		
		System.out.println("Printing all accounts");	
		service.getAllAccounts();
		System.out.println("---------------------------------------------");	
		service.updateloanAccount(new LoanAccount(1510, "Sundharalingam", 5900, 500, 2));
		System.out.println("Printing all updated accounts");	
		service.getAllAccounts();
		
		}

}
