package com.example.AzureSample.model;

import lombok.Data;

import org.springframework.data.annotation.Id;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.azure.spring.data.cosmos.core.mapping.PartitionKey;

@Container(containerName = "employee")
@Data
public class Employee {

	@Id
	private String id;
	private Integer empId;
	private String name;

	@PartitionKey
	private String account;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(String id, Integer empId, String name, String account) {
		super();
		this.id = id;
		this.empId = empId;
		this.name = name;
		this.account = account;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

}
