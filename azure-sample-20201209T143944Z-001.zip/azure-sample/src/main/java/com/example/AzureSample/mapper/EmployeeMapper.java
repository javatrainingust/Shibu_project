package com.example.AzureSample.mapper;

import org.springframework.stereotype.Component;

import com.example.AzureSample.model.Employee;

@Component
public class EmployeeMapper {

	public Employee mapEmployeeDetail(Employee employee) {
		Employee emp = employee;
		return emp;
	}

}
