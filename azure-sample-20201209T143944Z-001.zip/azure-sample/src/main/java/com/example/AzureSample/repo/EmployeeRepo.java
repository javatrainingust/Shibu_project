package com.example.AzureSample.repo;

import org.springframework.stereotype.Repository;

import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import com.example.AzureSample.model.Employee;

@Repository
public interface EmployeeRepo extends
		ReactiveCosmosRepository<Employee, String> {

//	@Query(value = "select * from some where some.account = @name")
//	Flux<Employee> getEmpByName(@Param("name") String name);
//
//	void deleteByIdAndAccount(String id, PartitionKey partitionKey);

}
