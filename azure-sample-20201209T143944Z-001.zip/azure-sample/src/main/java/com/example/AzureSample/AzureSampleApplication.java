package com.example.AzureSample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzureSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AzureSampleApplication.class, args);
	}

}
