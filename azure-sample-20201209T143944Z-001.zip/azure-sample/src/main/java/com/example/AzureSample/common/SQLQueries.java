package com.example.AzureSample.common;

public class SQLQueries {

	public static String FETCH_ALL_WITH_LIMIT = "select * from emp where emp.account = @account offset @offset limit @limit";

}
