package com.example.AzureSample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import com.example.AzureSample.model.Employee;
import com.example.AzureSample.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	// *********************Working**********************

	@GetMapping(value = "/all")
	public Flux<Employee> getEmployeeList() {
		Flux<Employee> empList = service.getEmployeeList();
		return empList;
	}

	@GetMapping(value = "/get/{id}")
	public Mono<Employee> getEmployeeById(@PathVariable("id") String id) {
		Mono<Employee> employee = service.getEmployeeById(id);
		return employee;
	}

	@PostMapping(value = "/save")
	public Employee saveEmployee(@RequestBody Employee employee) {
		Employee newEmployee = service.saveEmployee(employee);
		return newEmployee;
	}

	@DeleteMapping(value = "/delete/{id}")
	public Mono<Employee> deleteEmployee(@PathVariable("id") String id) {
		Mono<Employee> resp = service.deleteEmployee(id);
		return resp;
	}

	@PutMapping(value = "/update")
	public Employee updateEmployee(@RequestBody Employee employee) {
		Employee newEmployee = service.updateEmployee(employee);
		return newEmployee;
	}

	@GetMapping(value = "/custom/{name}/{offset}/{limit}")
	public List<Employee> getEmployeeByCustomName(
			@PathVariable("name") String name,
			@PathVariable("offset") Integer offset,
			@PathVariable("limit") Integer limit) {
		List<Employee> employee = service
				.getEmpByNameQuery(name, offset, limit);
		return employee;
	}

	// ****************** Not working *******************

	// @DeleteMapping(value = "/delete/id/{id}")
	// public Mono<Employee> deleteEmployeeById(@PathVariable("id") String id) {
	// Mono<Employee> resp = service.deleteEmployeeById(id);
	// return resp;
	// }

	@GetMapping(value = "/id/{id}")
	public Mono<Employee> getEmployeeByIdAndPartition(
			@PathVariable("id") String id) {
		Mono<Employee> employee = service.getEmployeeByIdAndPartition(id);
		return employee;
	}

	// @GetMapping(value = "/query/{name}")
	// public Flux<Employee> getEmployeeByIdName(@PathVariable("name") String
	// name) {
	// Flux<Employee> employee = service.getEmployeeByIdQuery(name);
	// return employee;
	// }

}
