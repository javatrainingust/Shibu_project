package com.example.AzureSample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import com.azure.cosmos.models.PartitionKey;
import com.example.AzureSample.dao.EmployeeDAO;
import com.example.AzureSample.model.Employee;
import com.example.AzureSample.repo.EmployeeRepo;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo repo;

	@Autowired
	private EmployeeDAO dao;

	public Flux<Employee> getEmployeeList() {

		Flux<Employee> employeeList = repo.findAll();
		return employeeList;
	}

	public Employee saveEmployee(Employee employee) {
		Mono<Employee> savedEmployee = repo.save(employee);
		return savedEmployee.block();
	}

	public Employee updateEmployee(Employee employee) {
		Mono<Employee> response = repo.findById(employee.getId());
		Employee updateEmp = response.block();
		updateEmp.setName(employee.getName());
		Mono<Employee> savedEmployee = repo.save(updateEmp);
		return savedEmployee.block();
	}

	public Mono<Employee> deleteEmployee(String id) {
		Mono<Employee> response = repo.findById(id);
		Mono<Employee> deleteResponse = response.flatMap(emp -> repo
				.delete(emp).then(Mono.just(emp)));
		return deleteResponse;
	}

	public Mono<Employee> getEmployeeById(String id) {
		Mono<Employee> response = repo.findById(id);
		return response;
	}

	// public Mono<Employee> deleteEmployeeById(String id) {
	// Mono<Employee> response = repo.findById(id);
	// String partitionKey = response.block().getAccount();
	// repo.deleteByIdAndAccount(id, new PartitionKey(partitionKey));
	// return response;
	// }

	public Mono<Employee> getEmployeeByIdAndPartition(String id) {
		Mono<Employee> response = repo
				.findById(id, new PartitionKey("walmart"));
		return response;
	}

	// public Flux<Employee> getEmployeeByIdQuery(String name) {
	// Flux<Employee> response = repo.getEmpByName(name);
	// return response;
	// }

	public Mono<Employee> getEmployeeByCustomQueryId(String id) {
		Mono<Employee> response = repo
				.findById(id, new PartitionKey("walmart"));
		return response;
	}

	public List<Employee> getEmpByNameQuery(String name, Integer offset,
			Integer limit) {
		List<Employee> empList = dao.getEmployeesWithLimit(name, offset, limit);
		return empList;
	}

}
